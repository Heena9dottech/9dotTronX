<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use App\Models\User;
use App\Models\ReferralRelationship;

$john = User::where('username', 'john')->first();
echo "John ID: {$john->id}\n";

// Check john's spillover slot
$spillover = ReferralRelationship::where('user_id', $john->id)
    ->where('is_spillover_slot', true)
    ->first();

if ($spillover) {
    echo "John spillover slot: Round {$spillover->tree_round}\n";
    echo "John spillover under: {$spillover->upline_username}\n";
}

// Check all entries for john as tree owner
$allEntries = ReferralRelationship::where('tree_owner_id', $john->id)->get();
echo "Total entries for john as tree owner: {$allEntries->count()}\n";

// Check by round
$rounds = $allEntries->groupBy('tree_round');
foreach ($rounds as $round => $entries) {
    $regularCount = $entries->where('is_spillover_slot', false)->count();
    $spilloverCount = $entries->where('is_spillover_slot', true)->count();
    echo "Round {$round}: {$regularCount} regular, {$spilloverCount} spillover\n";
}

// Check all users and their tree_owner_id
echo "\nAll users and their tree_owner_id:\n";
$allUsers = User::where('username', '!=', 'admin')->get();
foreach ($allUsers as $user) {
    $entry = ReferralRelationship::where('user_id', $user->id)->first();
    if ($entry) {
        echo "{$user->username} (ID: {$user->id}) -> tree_owner_id: {$entry->tree_owner_id}, round: {$entry->tree_round}\n";
    }
}

// Check lena specifically
$lena = User::where('username', 'lena')->first();
if ($lena) {
    $lenaEntry = ReferralRelationship::where('user_id', $lena->id)->first();
    if ($lenaEntry) {
        echo "\nLena is in Round: {$lenaEntry->tree_round}\n";
        echo "Lena is under: {$lenaEntry->upline_username}\n";
        echo "Lena's tree_owner_id: {$lenaEntry->tree_owner_id}\n";
    }
}
